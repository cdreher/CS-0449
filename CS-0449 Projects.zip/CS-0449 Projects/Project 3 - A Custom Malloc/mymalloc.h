//Collin Dreher

void *my_buddy_malloc(int size);
void my_free(void *ptr);
void dump_heap();
void *divider(int index, int baseCase);