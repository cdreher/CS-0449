#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>

struct Block *fList[26];
static void *base = NULL;
int MAX_MEM = 1 << 30;

struct Block{
	char head;
	struct Block *prev;   // pointer to prev block
	struct Block *next;   // pointer to next block
};

static struct Block *head = NULL;       // head of list

/*divider takes a struct Block larger than the size we need and recursively divides it until
 *it is the correct size.  It adds these two nodes into the correct size in our freeArray
 *and returns a pointer to the 1st of the two nodes.
 *
 */
void *divider(int index, int baseCase) {
		
	struct Block *temporary = fList[index + 1]; // get large potion of memory to divide
	

	int size = ((1 << (index + 6)) / 2);//calculates half of this large chunck of memory
	struct Block *toSplit =(char *)temporary + size; // adds to our curernt position to get the pointer directly in the middle
        //printf("index=%d, size=%d\n", index, size);

	if(temporary->next != NULL) {
		fList[index+1] = temporary->next;
		temporary->next= NULL;
		fList[index+1]->prev = NULL;
	}
	else{
		fList[index+1]=NULL;
	}	
	//checking to see if the index we are removing these nodes from have something it it so we don't 
	//lose the other nodes in the fList

	temporary->next = toSplit;
	toSplit->prev = temporary;
	//creating 2 independent nodes temporary and toSplit

	if(fList[index] != NULL){
		toSplit->next = fList[index];
		fList[index]->prev=toSplit;
	}
	else{
		toSplit->next = NULL;
	}
	//checking to see if index we are placing these nodes in have a struct Block already in them


	fList[index] = temporary;//places our 2 nodes in our fList
	temporary->prev=NULL;//sets the prev to our first struct Block in our fList to NULL

	temporary->head = index+5;
	toSplit->head = index+5;
	//resetting the headers to the correct size

	if(fList[index]->head == baseCase+5){
		fList[index]->head |=128;
		void *tmp = fList[index];
                fList[index]=fList[index]->next;
		if(fList[index]!=NULL)
		{
			fList[index]->prev=NULL;	
		}
		return tmp;
	}
	else{
		divider(index-1,baseCase);
	}
	//recursion base case.
}
/*
 *power function finds what index is large enough to 
 *store our malloced size.  It does it by bit shifting 1 to 
 * increment by the powers of 2.
 */
int power(int num)
{
	int i;
	for(i=5; i<=30; i++)
	{
		if((1<<i) >num)
			{
				return i;
			}
	}
}

/*findFreeSpace itterates through our array starting from the best possible fit for our size
 *if that size exists we will return the pointer to that struct Block and remove it from our array
 *otherwise we will need to call our divider functions to create a better fit for the space
 *we are trying to allocate.
 */
void *findFreeSpace(int size){
	int i;
	for(i=size-5; i<26; i++)//accounting for the -5 we can just return -5 then dont need to sub
		{
			if(fList[i] != NULL)
			{	
				if(fList[i]->head==size)// added +5
				{
					fList[i]->head |=128;//setting the first bit to 1 --> used
					void *temporaryPnt= fList[i];
					fList[i]=fList[i]->next;
					if(fList[i]!=NULL)
					{
						fList[i]->prev=NULL;
					}
					return temporaryPnt;
				} 
				//case if we have a struct Block of the correct size
				else
				{ 
					void *pointer = divider(i-1, size-5);
					return pointer;
				}
				//case if we need to make a struct Block of the correct size
			}
		}
		printf("We don't have any more memory sorry");
// if we get here we dont have enough memory to allocate anymore
}

void *my_buddy_malloc(int size)
{
    if(base == NULL)
    	{
            base = mmap(NULL, MAX_MEM, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANON, 0, 0);
       		fList[25]=base;
			fList[25] -> head = 30;
			fList[25]->next=NULL;
			fList[25]->prev = NULL;
 		}

    assert(base!=NULL);

	int thePower = power(size);
	void *space = findFreeSpace(thePower);       
	//return space;
}


void my_free(void *ptr)
{
	struct Block *free = (struct Node*)ptr;//casting our void pointer as a struct struct Block

	if(free->head ==30 )
	{
		return;
	}
	//recursion base case

	free->head &=127;//setting 1st bit as 0 -->freed
	
        void *val = ((ptr-base) ^ (1 << free->head)) + base;
        struct Block *findBuddy = (struct Node*)val;
	unsigned char myBits= findBuddy->head;
	myBits=myBits>>7;
	//calculation for buddy to see if our buddy is available or not

	if(myBits == 0 ) 
	{
		//if we get here our buddy is free!
		if(findBuddy->next==NULL && findBuddy->prev==NULL)
		{
				fList[findBuddy->head-5]=NULL;
		}
		else if(findBuddy->next == NULL && findBuddy->prev != NULL)
		{
				struct Block *supertemporary = findBuddy->prev;
				supertemporary->next = NULL;
				fList[findBuddy->head-5]=NULL;
		}
		else if(findBuddy->next!= NULL && findBuddy->prev != NULL)
		{
				struct Block *supertemporaryPrev = findBuddy->prev;
				struct Block *supertemporaryNext = findBuddy->next;		
				supertemporaryPrev->next = supertemporaryNext;
				supertemporaryNext->prev = supertemporaryPrev;
				fList[findBuddy->head-5]=NULL;
		}
		else if(findBuddy->next!=NULL && findBuddy->prev == NULL)
		{
				
				fList[findBuddy->head-5] = findBuddy->next;
				fList[findBuddy->head-5]->prev = NULL;
				findBuddy->next = NULL;
		}
		//deletion of buddy from our fList (so we can move it up to the next index)
		
		int greater = val-ptr;//calculation to see what struct Block is the front struct Block
		if(greater>0)
		{
			//ptr
			free->head +=1;	
			if(fList[free->head-5]!=NULL)
			{
				fList[free->head-5]->prev=free;
				free->next=fList[free->head-5];
				fList[free->head-5]=free;
				free->prev=NULL;
				my_free(ptr);		
			}
			else
			{
				fList[free->head-5]=free;	
				free->prev= NULL;
				free->next = NULL;
			}
		}
		//colasing the nodes together and moving them up an index
		else
		{
			//val
			findBuddy->head +=1;
			if(fList[findBuddy->head-5]!=NULL)
			{
				fList[findBuddy->head-5]->prev=findBuddy;
				findBuddy->next=fList[findBuddy->head-5];
				fList[findBuddy->head-5]=findBuddy;
				findBuddy->prev= NULL;
				my_free(val);

			}
			else
			{
				fList[findBuddy->head-5]=findBuddy;	
				findBuddy->prev= NULL;
				findBuddy->next= NULL;
			}
		}	
		//colasing the nodes together and moving them up and index
	}
	else
	{
		//our buddy didnt exist :(
		if(fList[free->head-5]!=NULL)
		{
			free->next=fList[free->head-5];
			fList[free->head-5]->prev = free;
			fList[free->head-5]=free;
			free->prev = NULL;
		}
		else
		{
			free->next=NULL;
			free->prev = NULL;
			fList[free->head-5]=free;
		}
		//check to see if the place we are putting our struct Block has another struct Block
	}

}